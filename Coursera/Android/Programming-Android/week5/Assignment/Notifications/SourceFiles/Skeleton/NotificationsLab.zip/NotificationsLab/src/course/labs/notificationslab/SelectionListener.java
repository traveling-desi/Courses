package course.labs.notificationslab;

public interface SelectionListener {
	public void onItemSelected(int position);
}